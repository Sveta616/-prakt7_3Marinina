import kotlin.math.max
import kotlin.math.min
import kotlin.math.round

fun main()
{
    try{
        println("Дан первый прямоугольник")
        println("ведите координату x1")
        var x1= readLine()!!.toDouble()
        println("ведите координату y1")
        var y1= readLine()!!.toDouble()
        println("ведите координату x2")
        var x2= readLine()!!.toDouble()
        println("ведите координату y2")
        var y2= readLine()!!.toDouble()
        println("Дан второй прямоугольник")
        println("ведите координату x3")
        var x3= readLine()!!.toDouble()
        println("ведите координату y3")
        var y3= readLine()!!.toDouble()
        println("ведите координату x4")
        var x4= readLine()!!.toDouble()
        println("ведите координату y4")
        var y4= readLine()!!.toDouble()
        var a=max(x1,x3)
        var b=min(y2,y4)
        var c=min(x2,x4)
        var d=max(y1,y3)
        var e=c-a
        var f=b-d
        var rez=e*f
        when{
            (e<0 || f<0)->println("0")
            else->println("Площадь пересечения="+ (String.format("%.2f",rez)))
        }

    }catch(e:Exception)
    {
        println("Введите символ");
    }
}