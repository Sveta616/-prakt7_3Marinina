import kotlin.math.pow
fun main()
{
    try{
        val p=7.9
        val m=56.0
        val k=10.0
        val n=6.02*k.pow(23)
        println("Введите объём")
        var v= readLine()!!.toDouble()
        var n1=p*v*n/m
        when{
            (p>=0&&m>=0&&k>=0&&n>=0)->println("Кол-во атомов="+ String.format("%.2f",n1))
            else->println("число не может быть отрицательным или равно 0")
        }
    }catch(e:Exception)
    {
        println("Введите символ");
    }
}